import { useState } from 'react';
import { Layout, Menu, Avatar, Dropdown } from 'antd';
import {
  ClockCircleOutlined,
  FileTextOutlined,
  CheckSquareOutlined,
  BarChartOutlined,
  LogoutOutlined,
  UserOutlined,
  MoreOutlined,
  HomeOutlined,
  SettingOutlined,
  SyncOutlined,
} from '@ant-design/icons';
import { useAuth } from '../stores/authStore';

const { Sider, Header, Content } = Layout;

const roleMenus = {
  Employee: [
    { key: 'workhour', label: '工时填报', icon: <ClockCircleOutlined /> },
    { key: 'history', label: '工时历史', icon: <FileTextOutlined /> },
    { key: 'statistics', label: '统计分析', icon: <BarChartOutlined /> },
  ],
  PM: [
    { key: 'workhour', label: '工时填报', icon: <ClockCircleOutlined /> },
    { key: 'history', label: '工时历史', icon: <FileTextOutlined /> },
    { key: 'approval', label: '工时审批', icon: <CheckSquareOutlined /> },
    { key: 'statistics', label: '统计分析', icon: <BarChartOutlined /> },
  ],
  DeptManager: [
    { key: 'workhour', label: '工时填报', icon: <ClockCircleOutlined /> },
    { key: 'history', label: '工时历史', icon: <FileTextOutlined /> },
    { key: 'approval', label: '工时审批', icon: <CheckSquareOutlined /> },
    { key: 'statistics', label: '统计分析', icon: <BarChartOutlined /> },
  ],
  HRAttendance: [
    { key: 'workhour', label: '工时填报', icon: <ClockCircleOutlined /> },
    { key: 'history', label: '工时历史', icon: <FileTextOutlined /> },
    { key: 'approval', label: '工时审批', icon: <CheckSquareOutlined /> },
    { key: 'statistics', label: '统计分析', icon: <BarChartOutlined /> },
  ],
  Admin: [
    { key: 'workhour', label: '工时填报', icon: <ClockCircleOutlined /> },
    { key: 'history', label: '工时历史', icon: <FileTextOutlined /> },
    { key: 'approval', label: '工时审批', icon: <CheckSquareOutlined /> },
    { key: 'statistics', label: '个人统计', icon: <BarChartOutlined /> },
    { key: 'adminStats', label: '全公司统计', icon: <BarChartOutlined /> },
    { key: 'admin', label: '系统管理', icon: <SettingOutlined /> },
    { key: 'sync', label: '数据同步', icon: <SyncOutlined /> },
  ],
  Director: [
    { key: 'workhour', label: '工时填报', icon: <ClockCircleOutlined /> },
    { key: 'history', label: '工时历史', icon: <FileTextOutlined /> },
    { key: 'approval', label: '工时审批', icon: <CheckSquareOutlined /> },
    { key: 'statistics', label: '统计分析', icon: <BarChartOutlined /> },
  ],
};

const getPageTitle = (page) => {
  const titles = {
    workhour: '工时填报',
    history: '工时历史',
    approval: '审批管理',
    statistics: '个人统计',
    adminStats: '全公司统计',
    admin: '系统管理',
    sync: '数据同步',
  };
  return titles[page] || '工时填报';
};

const CustomLayout = ({ currentPage, onPageChange, children }) => {
  const { logout, getCurrentUser } = useAuth();
  const user = getCurrentUser();

  const userMenuItems = [
    {
      key: 'logout',
      icon: <LogoutOutlined />,
      label: '退出登录',
      onClick: () => {
        logout();
        window.location.href = '/login';
      },
    },
  ];

  const menuItems = (roleMenus[user?.role] || roleMenus.Employee).map((item) => ({
    key: item.key,
    icon: item.icon,
    label: item.label,
  }));

  return (
    <Layout style={{ minHeight: '100vh', background: '#f0f2f5' }}>
      <Sider
        width={200}
        style={{
          background: '#fff',
          position: 'fixed',
          left: 0,
          top: 0,
          bottom: 0,
          zIndex: 100,
          borderRight: '1px solid #f0f0f0',
        }}
      >
        <div style={{ padding: '20px 16px', borderBottom: '1px solid #f0f0f0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 32, height: 32, background: '#1890ff', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <ClockCircleOutlined style={{ fontSize: 18, color: '#fff' }} />
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#1f1f1f' }}>工时填报系统</div>
              <div style={{ fontSize: 10, color: '#999' }}>Work Hour System</div>
            </div>
          </div>
        </div>

        <Menu
          mode="inline"
          selectedKeys={[currentPage]}
          onClick={({ key }) => onPageChange(key)}
          items={menuItems}
          style={{
            borderRight: 'none',
            marginTop: 8,
            background: 'transparent',
          }}
        />
      </Sider>

      <Layout style={{ marginLeft: 200 }}>
        <Header
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '0 24px',
            background: '#fff',
            boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            position: 'fixed',
            right: 0,
            left: 200,
            top: 0,
            zIndex: 99,
            height: 56,
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <HomeOutlined style={{ color: '#999', fontSize: 16 }} />
            <span style={{ color: '#999' }}>/</span>
            <span style={{ color: '#1890ff', fontWeight: 500 }}>{getPageTitle(currentPage)}</span>
          </div>

          <Dropdown
            menu={{ 
              items: [
                {
                  key: 'logout',
                  icon: <LogoutOutlined />,
                  label: '退出登录',
                  onClick: () => {
                    logout();
                    window.location.href = '/login';
                  },
                },
              ]
            }}
            placement="bottomRight"
            overlayStyle={{
              borderRadius: 8,
              boxShadow: '0 2px 12px rgba(0, 0, 0, 0.1)',
              border: '1px solid #f0f0f0',
              padding: 4,
            }}
          >
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 4,
                padding: '8px 12px',
                borderRadius: 8,
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                minWidth: 60,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#f5f5f5';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
              }}
            >
              <Avatar 
                size={36} 
                icon={<UserOutlined style={{ fontSize: 18 }} />}
                style={{
                  background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
                  border: '2px solid #ffffff',
                  boxShadow: '0 2px 8px rgba(99, 102, 241, 0.25)',
                }}
              />
              <div style={{ fontSize: 13, color: '#333333', fontWeight: 600 }}>
                {user?.role === 'Admin' && '管理员'}
                {user?.role === 'Director' && '高管'}
                {user?.role === 'DeptManager' && '部门经理'}
                {user?.role === 'PM' && '项目经理'}
                {user?.role === 'HRAttendance' && 'HR专员'}
                {user?.role === 'Employee' && '普通员工'}
              </div>
            </div>
          </Dropdown>
        </Header>

        <Content
          style={{
            padding: '20px',
            background: '#f0f2f5',
            minHeight: '100vh',
            marginTop: 56,
          }}
        >
          {children}
        </Content>
      </Layout>
    </Layout>
  );
};

export default CustomLayout;
